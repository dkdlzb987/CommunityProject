package com.company;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

public class SearchHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		   CDao dao = new CDao();
		   String mainSearch = request.getParameter("mainSearch");
		      
	      Vector<CDto> s = dao.getSearch(mainSearch);

	      request.setAttribute("search", s);
	      return "/search.jsp";
	}

}
