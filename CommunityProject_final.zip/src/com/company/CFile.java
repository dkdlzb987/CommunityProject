package com.company;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class CFile {
	HttpServletRequest request;
	MultipartRequest mrequest;
	
	public CFile(HttpServletRequest request) {
		this.request = request; 
	}
	
	public MultipartRequest fileUpload(){
		String saveDirectory = request.getServletContext().getRealPath("/upload");
		File f = new File(saveDirectory);
		if(!f.exists()){// 실제 저 폴더가 존재하지 않는다면
			f.mkdir();// 위에 위치에 실제로 폴더 만들기
		}	
		int maxPostSize = 1024*1024*10;//10메가 업로드 가능한 최대크기
		String encoding = "utf-8";
		DefaultFileRenamePolicy policy= new DefaultFileRenamePolicy(); // 중복된 파일 이름 처리
		try {
			mrequest 
					= new MultipartRequest(request, 
								saveDirectory, 
								maxPostSize, 
								encoding, 
								policy);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// 이줄이 실행되는순간 파일 업로드는 끝.
		
		
		return mrequest;
	}
	
}
