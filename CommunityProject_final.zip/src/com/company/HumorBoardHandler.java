package com.company;

import java.util.HashMap;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

public class HumorBoardHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		CDao dao = new CDao();
		/*Vector<CDto> v = dao.getData();
		request.setAttribute("data", v);*/

		int totalCount = dao.selectDataCnt();	
		int pageRow = 10;
		int nowPage = 1;
		int totalPage =  (int)Math.ceil(totalCount/(double)pageRow);
		int countPage = 10;
		if(request.getParameter("nowPage") != null){
			nowPage =  Integer.parseInt(request.getParameter("nowPage"));
		}
		
		int startPage=((nowPage-1)/countPage)*countPage + 1;
		int endPage=startPage-1 + countPage;
		
		if(endPage>totalPage){
			endPage=totalPage;
		}
		
		HashMap<String, Integer> map = new HashMap<>();
		map.put("nowPage", nowPage);
		map.put("startPage", startPage);
		map.put("endPage", endPage);
		map.put("totalPage", totalPage);
		
		Vector<CDto> v = dao.selectHumorData(nowPage, pageRow);		
		request.setAttribute("data", v);
		request.setAttribute("pageData",map);		
		
		
		
		return"/humorBoard.jsp";
	}

}
