package com.company;

import javax.servlet.http.HttpServletRequest;

public interface CHandler {
	public String process(HttpServletRequest request);
}
