package com.company;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class SelectHandler implements CHandler{
	public String process(HttpServletRequest request){
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		CDao dao = new CDao();
		Vector<CDto> v = dao.getAd();
		Vector<CDto> r = dao.getRankTitle();
		Vector<CDto> g = dao.getGoodCount();
		request.setAttribute("data", v);
		request.setAttribute("rank", r);
		request.setAttribute("good", g);
		if(id!=null){
			CDto dto = dao.login(id,pw);
			HttpSession session = request.getSession();
			session.setAttribute("data1",dto);
		}
		return "main.jsp";
	}
}
