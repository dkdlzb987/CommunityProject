package com.company;

import javax.servlet.http.HttpServletRequest;

public class FoundPwHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		return "foundPw.jsp";
	}

}
