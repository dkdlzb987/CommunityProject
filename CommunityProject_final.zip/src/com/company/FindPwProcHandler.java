package com.company;

import javax.servlet.http.HttpServletRequest;

public class FindPwProcHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		CDao dao = new CDao();
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String answer = request.getParameter("answer");
		String findpw = dao.findPw(id,name,phone,answer);
		request.setAttribute("findpw", findpw);
		return "/FoundPw.do";
	}

}
