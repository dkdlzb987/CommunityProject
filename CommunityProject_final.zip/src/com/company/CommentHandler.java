package com.company;


import javax.servlet.http.HttpServletRequest;


public class CommentHandler implements CHandler {

   @Override
   public String process(HttpServletRequest request) {
      CDao dao = new CDao();
      String comment = request.getParameter("comment");
      String author = request.getParameter("author");
      int idx = Integer.parseInt(request.getParameter("idx"));
      
      dao.updateComment(idx, comment, author);

      return "ReadBoard.do?idx="+idx;
   }

}