package com.company;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class CDao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null; // select占쎈퓠占쎄퐣筌랃옙 占쎄텢占쎌뒠 => executeQuery();
	String sql = null;
	int result = 0;// insert, delete, update 占쎈퓠占쎄퐣筌랃옙 占쎄텢占쎌뒠 => executeUpdate();
	DataSource pool = null;
	
	//�뚣끇苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡
	public CDao() {		
		try{
			InitialContext initialContext = new InitialContext();// Contex占쎌겫占쎈열 占쎌젔域뱀눖占쏙옙�땾
			pool = (DataSource) initialContext.lookup("java:comp/env/dsdbcp");//ds揶쏉옙 pool 占쎌뵠占쎌뵬�⑨옙 占쎄문揶쏄낱釉�筌롳옙 占쎈쭡.
		}catch (NamingException ne) {
			ne.printStackTrace();
		}
	}
	
	public void freeConn(ResultSet r, PreparedStatement p, Connection c){
		try{
			if(r != null) r.close();
			if(p != null) p.close();
			if(c != null) c.close();
		}catch(SQLException sqle){
			sqle.printStackTrace();
		}
	}// select 占쎌뵬野껋럩�뒭
	
	public void freeConn(PreparedStatement p, Connection c){
		try{			
			if(p != null) p.close();
			if(c != null) c.close();
		}catch(SQLException sqle){
			sqle.printStackTrace();
		}
	}// select揶쏉옙 占쎈툡占쎈빜 野껋럩�뒭
	
	
	public Vector<CDto> getAd(){
		Vector<CDto> v = new Vector<>();
		
		try{			
			sql = "SELECT * from ad order by rand() limit 1";
			conn = pool.getConnection();// �뚢뫀苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡 占쎄퐫占쎌뱽 占쎌굙占쎌젟
			pstmt = conn.prepareStatement(sql);// 占쎈뼄占쎈뻬占쎈막 �뤃�됎� 占쎄퐨占쎄문占쎈퉸 雅뚯눊由�
			rs = pstmt.executeQuery();// 占쎈뼄占쎈뻬
			
			while(rs.next()){
				CDto dto = new CDto();
				dto.setIdx(rs.getInt("idx"));
				dto.setAdname(rs.getString("adname"));
				dto.setUrl(rs.getString("url"));
				v.add(dto);
			}
			
		}catch(SQLException sqle){
			sqle.printStackTrace();// 占쎈퓠占쎌쑎 �굜�꼷�꼧占쎈퓠 �빊�뮆�젾
		}finally {
			// 占쎈뼍疫뀐옙
			freeConn(rs,pstmt,conn);			
		}
		
		
		return v;
	}
	
	public int insertAd(String adname, String url){		
		try{
			sql = "INSERT INTO ad VALUES (NULL,?,?)";
			conn = pool.getConnection();// �뚣끇苑뽳옙�� 揶쏉옙占쎌죬占쎌궎疫뀐옙
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, adname);
			pstmt.setString(2, url);			
			
			result = pstmt.executeUpdate();
			
			
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			freeConn(pstmt, conn);
		}
		
		return result;
	}
	public CDto login(String id, String pw){
		
		CDto dto = new CDto();
		
		try{			
			conn = pool.getConnection();
			String sql = "select * from cmember where id=? and pw=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			if(rs.next()){
				
				dto.setIdx(rs.getInt(1));
				dto.setName(rs.getString(2));
				dto.setId(rs.getString(3));
				dto.setPw(rs.getString(4));
				dto.setNickname(rs.getString(5));
				dto.setEmail(rs.getString(6));
				dto.setJoinDate(rs.getString(7));
				dto.setPhone(rs.getString(8));
				dto.setAddr(rs.getString(9));
				dto.setAnswer(rs.getString(10));
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			freeConn(pstmt, conn);
		}
		
		return dto;
	}

	public int registMember(String name, String id, String pw, String nickname, String email, String phone, String addr, String answer){		
		try{
			sql = "INSERT INTO cmember VALUES (NULL,?,?,?,?,?,now(),?,?,?)";
			conn = pool.getConnection();// �뚣끇苑뽳옙�� 揶쏉옙占쎌죬占쎌궎疫뀐옙
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, id);
			pstmt.setString(3, pw);
			pstmt.setString(4, nickname);
			pstmt.setString(5, email);
			pstmt.setString(6, phone);
			pstmt.setString(7, addr);
			pstmt.setString(8, answer);
			
			result = pstmt.executeUpdate();
			
			
		}catch (SQLException e) {
			e.printStackTrace();
			System.out.println("占쎈즼占쎈툡揶쏉옙");
		}finally {
			freeConn(pstmt, conn);
		}
		
		return result;
	}
	
	public Vector<CDto> getData(){
		Vector<CDto> v = new Vector<>();
		
		try{			
			sql = "SELECT * from cboard";
			conn = pool.getConnection();// �뚢뫀苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡 占쎄퐫占쎌뱽 占쎌굙占쎌젟
			pstmt = conn.prepareStatement(sql);// 占쎈뼄占쎈뻬占쎈막 �뤃�됎� 占쎄퐨占쎄문占쎈퉸 雅뚯눊由�
			rs = pstmt.executeQuery();// 占쎈뼄占쎈뻬
			
			while(rs.next()){
				CDto dto = new CDto();
				dto.setIdx(rs.getInt("idx"));
				dto.setTitle(rs.getString("title"));
				dto.setAuthor(rs.getString("author"));
				dto.setCreationDate(rs.getString("creationDate"));
				dto.setGoodCount(rs.getInt("goodCount"));
				v.add(dto);
			}
			
		}catch(SQLException sqle){
			sqle.printStackTrace();// 占쎈퓠占쎌쑎 �굜�꼷�꼧占쎈퓠 �빊�뮆�젾
		}finally {
			// 占쎈뼍疫뀐옙
			freeConn(rs,pstmt,conn);			
		}
		
		
		return v;
	}

	public CDto getReadContent(int idx) {

		CDto dto = new CDto();
		
		try{			
			sql = "SELECT * from cboard where idx=?";
			conn = pool.getConnection();// �뚢뫀苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡 占쎄퐫占쎌뱽 占쎌굙占쎌젟
			pstmt = conn.prepareStatement(sql);// 占쎈뼄占쎈뻬占쎈막 �뤃�됎� 占쎄퐨占쎄문占쎈퉸 雅뚯눊由�
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();// 占쎈뼄占쎈뻬
			
			if(rs.next()){				
				dto.setIdx(rs.getInt(1));
				System.out.println("idx: "+rs.getInt(1));
				dto.setTitle(rs.getString(2));
				dto.setAuthor(rs.getString("author"));
				dto.setCreationDate(rs.getString("creationDate"));
				dto.setContent(rs.getString("content"));
				dto.setGoodCount(rs.getInt("goodCount"));
				dto.setBadCount(rs.getInt("badCount"));
				dto.setFileName(rs.getString(9));
			}	
			
		}catch(SQLException sqle){
			sqle.printStackTrace();// 占쎈퓠占쎌쑎 �굜�꼷�꼧占쎈퓠 �빊�뮆�젾
		}finally {
			// 占쎈뼍疫뀐옙
			freeConn(rs,pstmt,conn);			
		}
		return dto;

	}

	
	public int writeBoard(String title, String content, String name, int boardNumber) {
		int resultPage = 0;
		try{			
			sql = "INSERT INTO cboard VALUES (NULL,?,?, NOW(),?,?,0,0,0,'')";
			conn = pool.getConnection();// �뚢뫀苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡 占쎄퐫占쎌뱽 占쎌굙占쎌젟
			pstmt = conn.prepareStatement(sql);// 占쎈뼄占쎈뻬占쎈막 �뤃�됎� 占쎄퐨占쎄문占쎈퉸 雅뚯눊由�
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setString(3, name);
			pstmt.setInt(4, boardNumber);
			result = pstmt.executeUpdate();
			resultPage = boardNumber;
			
		}catch(SQLException sqle){
			sqle.printStackTrace();// 占쎈퓠占쎌쑎 �굜�꼷�꼧占쎈퓠 �빊�뮆�젾
		}finally {
			// 占쎈뼍疫뀐옙
			freeConn(rs,pstmt,conn);			
		}
		return resultPage;
		
	}
	
	public int writeBoard(String title, String content, String name, String uploadFile, int boardNumber) {
		
		try{			
			sql = "INSERT INTO cboard VALUES (NULL,?,?, NOW(),?,?, 0,0,0,?)";
			conn = pool.getConnection();// �뚢뫀苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡 占쎄퐫占쎌뱽 占쎌굙占쎌젟
			pstmt = conn.prepareStatement(sql);// 占쎈뼄占쎈뻬占쎈막 �뤃�됎� 占쎄퐨占쎄문占쎈퉸 雅뚯눊由�
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setString(3, name);
			pstmt.setInt(4, boardNumber);
			pstmt.setString(5, uploadFile);
			result = pstmt.executeUpdate();
			
		}catch(SQLException sqle){
			sqle.printStackTrace();// 占쎈퓠占쎌쑎 �굜�꼷�꼧占쎈퓠 �빊�뮆�젾
		}finally {
			// 占쎈뼍疫뀐옙
			freeConn(rs,pstmt,conn);			
		}
		return result;
		
	}

	public int goodCount(int idx) {
		try{			
			sql = "UPDATE cboard set goodCount=goodCount+1 WHERE idx=?";
			
			conn = pool.getConnection();// �뚢뫀苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡 占쎄퐫占쎌뱽 占쎌굙占쎌젟
			pstmt = conn.prepareStatement(sql);// 占쎈뼄占쎈뻬占쎈막 �뤃�됎� 占쎄퐨占쎄문占쎈퉸 雅뚯눊由�
			pstmt.setInt(1, idx);
			result = pstmt.executeUpdate();
			
		}catch(SQLException sqle){
			sqle.printStackTrace();// 占쎈퓠占쎌쑎 �굜�꼷�꼧占쎈퓠 �빊�뮆�젾
		}finally {
			// 占쎈뼍疫뀐옙
			freeConn(rs,pstmt,conn);			
		}
		
		return result;
	
	}
	
	public int selectDataCnt() {
		try{
			conn = pool.getConnection();
			String sql = "select count(idx) from cboard";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				result = rs.getInt(1);
			}
			
		}catch(SQLException sqle){
			sqle.printStackTrace();
		}finally {
			freeConn(rs, pstmt, conn);
		}
		return result;
	}
	
	public Vector<CDto> selectHumorData(int nowPage, int cnt){
		Vector<CDto> v = new Vector<>();
		try{
			conn = pool.getConnection();
			String sql = "SELECT * FROM cboard WHERE boardNumber=1 LIMIT ?,?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, (nowPage-1)*cnt);
			pstmt.setInt(2, cnt);
			rs = pstmt.executeQuery();
			while(rs.next()){
				CDto dto = new CDto();
				 dto.setIdx(rs.getInt(1));
		         dto.setTitle(rs.getString(2));
		         dto.setAuthor(rs.getString("author"));
		         dto.setCreationDate(rs.getString("creationDate"));
		         dto.setContent(rs.getString("content"));
		         dto.setGoodCount(rs.getInt("goodCount"));
		         dto.setBadCount(rs.getInt("badCount"));
		         dto.setFileName(rs.getString(9));
				v.add(dto);
			}
			
		}catch (SQLException sqle) {
			sqle.printStackTrace();
		}finally {
			freeConn(rs, pstmt, conn);
		}
		return v;
	}
	
	public Vector<CDto> selectPetData(int nowPage, int cnt){
		Vector<CDto> v = new Vector<>();
		try{
			conn = pool.getConnection();
			String sql = "SELECT * FROM cboard WHERE boardNumber=2 LIMIT ?,?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, (nowPage-1)*cnt);
			pstmt.setInt(2, cnt);
			rs = pstmt.executeQuery();
			while(rs.next()){
				CDto dto = new CDto();
				 dto.setIdx(rs.getInt(1));
		         dto.setTitle(rs.getString(2));
		         dto.setAuthor(rs.getString("author"));
		         dto.setCreationDate(rs.getString("creationDate"));
		         dto.setContent(rs.getString("content"));
		         dto.setGoodCount(rs.getInt("goodCount"));
		         dto.setBadCount(rs.getInt("badCount"));
		         dto.setFileName(rs.getString(9));
				v.add(dto);
			}
			
		}catch (SQLException sqle) {
			sqle.printStackTrace();
		}finally {
			freeConn(rs, pstmt, conn);
		}
		return v;
	}
	
	public Vector<CDto> selectGameData(int nowPage, int cnt){
		Vector<CDto> v = new Vector<>();
		try{
			conn = pool.getConnection();
			String sql = "SELECT * FROM cboard WHERE boardNumber=3 LIMIT ?,?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, (nowPage-1)*cnt);
			pstmt.setInt(2, cnt);
			rs = pstmt.executeQuery();
			while(rs.next()){
				CDto dto = new CDto();
				 dto.setIdx(rs.getInt(1));
		         dto.setTitle(rs.getString(2));
		         dto.setAuthor(rs.getString("author"));
		         dto.setCreationDate(rs.getString("creationDate"));
		         dto.setContent(rs.getString("content"));
		         dto.setGoodCount(rs.getInt("goodCount"));
		         dto.setBadCount(rs.getInt("badCount"));
		         dto.setFileName(rs.getString(9));
				v.add(dto);
			}
			
		}catch (SQLException sqle) {
			sqle.printStackTrace();
		}finally {
			freeConn(rs, pstmt, conn);
		}
		return v;
	}
	


	public int  badCount(int idx) {
		try{			
			sql = "UPDATE cboard set badCount=badCount+1 WHERE idx=?";
			
			conn = pool.getConnection();// �뚢뫀苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡 占쎄퐫占쎌뱽 占쎌굙占쎌젟
			pstmt = conn.prepareStatement(sql);// 占쎈뼄占쎈뻬占쎈막 �뤃�됎� 占쎄퐨占쎄문占쎈퉸 雅뚯눊由�
			pstmt.setInt(1, idx);
			result = pstmt.executeUpdate();
			
		}catch(SQLException sqle){
			sqle.printStackTrace();// 占쎈퓠占쎌쑎 �굜�꼷�꼧占쎈퓠 �빊�뮆�젾
		}finally {
			// 占쎈뼍疫뀐옙
			freeConn(rs,pstmt,conn);			
		}
		
		return result;
		
	}

	public Vector<CDto> getComment(int idx) {
		Vector<CDto> c = new Vector<>();
		try{
			conn = pool.getConnection();
			String sql = "SELECT * FROM ccomment WHERE boardIdx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();
			while(rs.next()){
				CDto dto = new CDto();
				 dto.setIdx(rs.getInt(1));
		         dto.setContent(rs.getString("content"));
		         dto.setCreationDate(rs.getString("creationDate"));
		         dto.setAuthor(rs.getString("author"));
				c.add(dto);
			}
			
		}catch (SQLException sqle) {
			sqle.printStackTrace();
		}finally {
			freeConn(rs, pstmt, conn);
		}
		return c;
	}

	public int updateComment(int idx, String comment, String author) {
	      try{         
	         sql = "INSERT INTO ccomment VALUES(NULL, ?, ?, NOW(), ?)";
	         
	         conn = pool.getConnection();// 컨넥션 가져오는 코드 넣을 예정
	         pstmt = conn.prepareStatement(sql);// 실행할 구문 선택해 주기
	         pstmt.setInt(1, idx);
	         pstmt.setString(2, comment);
	         pstmt.setString(3, author);
	         result = pstmt.executeUpdate();
	         
	      }catch(SQLException sqle){
	         sqle.printStackTrace();// 에러 콘솔에 출력
	      }finally {
	         // 닫기
	         freeConn(rs,pstmt,conn);         
	      }
	      
	      return result;
	   }
	
	public Vector<CDto> getRankTitle() {
        Vector<CDto> v = new Vector<>();
        try{         
           sql = "SELECT * FROM cboard order BY goodCount DESC ";
           
           conn = pool.getConnection();// �뚢뫀苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡 占쎄퐫占쎌뱽 占쎌굙占쎌젟
           pstmt = conn.prepareStatement(sql);// 占쎈뼄占쎈뻬占쎈막 �뤃�됎� 占쎄퐨占쎄문占쎈퉸 雅뚯눊由�
           rs = pstmt.executeQuery();
           
           while(rs.next()){
              CDto dto = new CDto();
              dto.setIdx(rs.getInt("idx"));
              dto.setTitle(rs.getString("title"));
              v.add(dto);
           }
        }catch(SQLException sqle){
           sqle.printStackTrace();// 占쎈퓠占쎌쑎 �굜�꼷�꼧占쎈퓠 �빊�뮆�젾
        }finally {
           // 占쎈뼍疫뀐옙
           freeConn(rs,pstmt,conn);         
        }
        
        return v;
        
     }

	public Vector<CDto> getGoodCount() {
		 Vector<CDto> v = new Vector<>();
	      try{         
	         sql = "SELECT goodCount FROM cboard order BY goodCount DESC ";
	         
	         conn = pool.getConnection();// �뚢뫀苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡 占쎄퐫占쎌뱽 占쎌굙占쎌젟
	         pstmt = conn.prepareStatement(sql);// 占쎈뼄占쎈뻬占쎈막 �뤃�됎� 占쎄퐨占쎄문占쎈퉸 雅뚯눊由�
	         rs = pstmt.executeQuery();
	         
	         while(rs.next()){
	            CDto dto = new CDto();
	            dto.setGoodCount(rs.getInt("goodCount"));
	            v.add(dto);
	         }
	      }catch(SQLException sqle){
	         sqle.printStackTrace();// 占쎈퓠占쎌쑎 �굜�꼷�꼧占쎈퓠 �빊�뮆�젾
	      }finally {
	         // 占쎈뼍疫뀐옙
	         freeConn(rs,pstmt,conn);         
	      }
	      
	      return v;
	      
	}
	
	   public Vector<CDto> getSearch(String searchWord) {
	       Vector<CDto> v = new Vector<>();
	         try{         
	            sql = "SELECT * FROM cboard WHERE title LIKE ?";// 占쎈뼄占쎌벉占쎈퓠 占쎄땀占쎌뒠 野껓옙占쎄퉳 �빊遺쏙옙
	            conn = pool.getConnection();// �뚢뫀苑뽳옙�� 揶쏉옙占쎌죬占쎌궎占쎈뮉 �굜遺얜굡 占쎄퐫占쎌뱽 占쎌굙占쎌젟
	            pstmt = conn.prepareStatement(sql);// 占쎈뼄占쎈뻬占쎈막 �뤃�됎� 占쎄퐨占쎄문占쎈퉸 雅뚯눊由�
	            pstmt.setString(1, "%"+searchWord+"%");
	            
	            rs = pstmt.executeQuery();
	            
	            while(rs.next()){
	               CDto dto = new CDto();	        
	               dto.setIdx(rs.getInt("idx"));
	               dto.setTitle(rs.getString("title"));
	               dto.setAuthor(rs.getString("author"));
	               dto.setCreationDate(rs.getString("creationDate"));
	               
	               
	               v.add(dto);
	            }
	         }catch(SQLException sqle){
	            sqle.printStackTrace();// 占쎈퓠占쎌쑎 �굜�꼷�꼧占쎈퓠 �빊�뮆�젾
	         }finally {
	            // 占쎈뼍疫뀐옙
	            freeConn(rs,pstmt,conn);         
	         }
	         
	         return v;
	         
	   }
	   public CDto getMemberData(String idx) {
			CDto cdto = new CDto();
			int iidx = Integer.parseInt(idx);
			
			try{			
				sql = "SELECT * FROM cmember WHERE idx=?";
				conn = pool.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, iidx);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()){				
					cdto.setIdx(rs.getInt("idx"));
					cdto.setName(rs.getString("name"));
					cdto.setId(rs.getString("id"));
					cdto.setPw(rs.getString("pw"));
					cdto.setNickname(rs.getString("nickname"));
					cdto.setEmail(rs.getString("email"));
					cdto.setPhone(rs.getString("phone"));
					cdto.setAddr(rs.getString("addr"));
					cdto.setAnswer(rs.getString("answer"));
				}				
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}finally {
				freeConn(rs,pstmt,conn);			
			}
			return cdto;
		}
	   
		public int updateMember(String name, String pw, String nickname, String email, String phone, String addr,String answer,
				String idx) {
			int iidx = Integer.parseInt(idx);
			try {
				sql = "update cmember set name=?, pw=?, nickname=?, email=?, phone=?, addr=? , answer=? where idx=?";
				conn = pool.getConnection();
				pstmt = conn.prepareStatement(sql);
				
				pstmt.setString(1, name);
				pstmt.setString(2, pw);
				pstmt.setString(3, nickname);
				pstmt.setString(4, email);
				pstmt.setString(5, phone);
				pstmt.setString(6, addr);
				pstmt.setString(7, answer);
				pstmt.setString(8, idx);

				result = pstmt.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				freeConn(pstmt, conn);
			}

			return result;
		}

		public String findId(String name, String phone) {
			
			String findid = null;
			try{			
				sql = "SELECT id FROM cmember WHERE name=? and phone=?";
				conn = pool.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, name);
				pstmt.setString(2, phone);
				
				rs = pstmt.executeQuery();
				while(rs.next()){				
					findid = rs.getString("id");
				}
				
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}finally {
				freeConn(rs,pstmt,conn);			
			}
			return findid;
			
			
		}

		public String findPw(String id, String name, String phone, String answer) {
			String findpw = null;
			try{			
				sql = "SELECT pw FROM cmember WHERE id=? and name=? and phone=? and answer=?";
				conn = pool.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				pstmt.setString(2, name);
				pstmt.setString(3, phone);
				pstmt.setString(4, answer);
				
				rs = pstmt.executeQuery();
				while(rs.next()){				
					findpw = rs.getString("pw");
				}
				
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}finally {
				freeConn(rs,pstmt,conn);			
			}
			return findpw;
		}
		
		public int deleteData(String idx){
			try{
				sql = "DELETE FROM cboard WHERE idx=?";
				conn = pool.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(idx));
				
				result = pstmt.executeUpdate();
			}catch (SQLException e) {
				e.printStackTrace();
			}finally {
				freeConn(pstmt, conn);
			}
			return result;
		}

}
