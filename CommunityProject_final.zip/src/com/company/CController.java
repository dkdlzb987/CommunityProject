package com.company;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.company.CFile;
import com.company.CDao;
import com.company.CDto;
import com.oreilly.servlet.MultipartRequest;

@WebServlet("/CCon")
public class CController extends HttpServlet {
	private static final long serialVersionUID = 1L; 
	Map<String, CHandler> map = new HashMap<>(); 
	
    public CController() {
        
        map.put("/Select.do", new SelectHandler());
        map.put("/Search.do", new SearchHandler());
        
        map.put("/PetBoard.do", new PetBoardHandler());
        map.put("/HumorBoard.do", new HumorBoardHandler());
        map.put("/GameBoard.do", new GameBoardHandler());
        
        map.put("/InsertAd.do", new InsertAdHandler());
        map.put("/InsertAdProc.do", new InsertAdProcHandler());
        map.put("/ReadBoard.do", new ReadBoardHandler());
        map.put("/WriteBoard.do", new WriteBoardHandler());
        map.put("/WriteBoardProc.do", new WriteBoardProcHandler());
        map.put("/DeleteBoardProc.do", new DeleteBoardProcHandler());
        
        map.put("/GoodCnt.do", new GoodCntHandler());
        map.put("/BadCnt.do", new BadCntHandler());
        map.put("/Comment.do", new CommentHandler());
        map.put("/Regist.do", new RegistHandler());
        map.put("/RegistProc.do", new RegistProcHandler());
        
        map.put("/Login.do", new LoginHandler());
        map.put("/LoginProc.do", new LoginProcHandler());
        
        map.put("/Update.do", new updateMemberHandler());
        map.put("/UpdateProc.do", new updateMemberProcHandler());
        
        map.put("/FoundId.do", new FoundIdHandler());
        map.put("/FindIdProc.do", new FindIdProcHandler());
        
        map.put("/FoundPw.do", new FoundPwHandler());
        map.put("/FindPwProc.do", new FindPwProcHandler());
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String tmpCmd = request.getRequestURI();
		System.out.println("���� ������ �� : "+ tmpCmd);
		int pos = tmpCmd.lastIndexOf("/");
		String cmd = tmpCmd.substring(pos); // => /BCon
		System.out.println("�߸� ������ �������� ����� �� : "+ cmd);
		
		String goPage = null;
		CHandler handler = null;
		
		handler = map.get(cmd);
		
		if(handler==null){
			handler = new SelectHandler();
		}
		 goPage=handler.process(request);
		RequestDispatcher rd = request.getRequestDispatcher(goPage);
		rd.forward(request, response);
		
	}
}

