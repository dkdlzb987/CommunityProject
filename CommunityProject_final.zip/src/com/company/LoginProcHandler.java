package com.company;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class LoginProcHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		CDao dao = new CDao();
		CDto dto = dao.login(id,pw);
		
			if(dto.getIdx()==0){
				return "/Login.do";
			}
		HttpSession session = request.getSession();
		session.setAttribute("data1",dto);
			
		return "/Select.do";
	}

}
