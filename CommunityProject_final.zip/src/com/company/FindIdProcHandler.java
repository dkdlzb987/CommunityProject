package com.company;


import javax.servlet.http.HttpServletRequest;

public class FindIdProcHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		CDao dao = new CDao();
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String findid = dao.findId(name,phone);
		request.setAttribute("findid", findid);
		return "/FoundId.do";
	}

}
