package com.company;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class updateMemberProcHandler implements CHandler {
	@Override
	public String process(HttpServletRequest request) {

		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String pw = request.getParameter("pw");
		String nickname = request.getParameter("nickname");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String addr = request.getParameter("addr");
		String answer = request.getParameter("answer");
		String idx = request.getParameter("idx");
		
		CDao dao = new CDao();
		dao.updateMember(name,pw,nickname,email,phone,addr, answer,idx);
		
		CDto dto = dao.getMemberData(idx);

		HttpSession session = request.getSession();
		session.setAttribute("data1",dto);
		
		return "/Select.do";
	}

}
