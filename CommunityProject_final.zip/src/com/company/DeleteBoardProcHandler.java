package com.company;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class DeleteBoardProcHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		/*HttpSession session = request.getSession();
		session.getAttribute("data1");
		
		String name = request.getParameter("name");
		String author = request.getParameter("author");
		
		if(name.equals(author)){
			String idx = request.getParameter("idx");
			CDao dao = new CDao();
			dao.deleteData(idx);
			
			return "Select.do";
		}else{
			return "Login.do";
		}*/
		
		
		String idx = request.getParameter("idx");
		CDao dao = new CDao();
		dao.deleteData(idx);
		return "Select.do";
	}

}
