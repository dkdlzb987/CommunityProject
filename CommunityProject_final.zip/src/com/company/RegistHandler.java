package com.company;

import javax.servlet.http.HttpServletRequest;

public class RegistHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		return "/regist.jsp";
	}

}
