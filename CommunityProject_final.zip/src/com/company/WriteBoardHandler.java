package com.company;

import javax.servlet.http.HttpServletRequest;

public class WriteBoardHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		request.setAttribute("boardNum",request.getParameter("boardNumber"));
		return "/writeBoard.jsp";
	}
	

}
