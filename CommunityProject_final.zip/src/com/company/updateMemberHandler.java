package com.company;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class updateMemberHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		String idx = request.getParameter("idx");
		
		CDao dao = new CDao();
		CDto dto = dao.getMemberData(idx);

		HttpSession session = request.getSession();
		session.setAttribute("data1",dto);
		return "/mypage.jsp";
	}

}
