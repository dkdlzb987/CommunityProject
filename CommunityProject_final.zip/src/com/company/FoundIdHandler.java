package com.company;

import javax.servlet.http.HttpServletRequest;

public class FoundIdHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		return "foundId.jsp";
	}

}
