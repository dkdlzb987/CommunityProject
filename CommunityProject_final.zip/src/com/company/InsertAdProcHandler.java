package com.company;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;

public class InsertAdProcHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		CFile f = new CFile(request);
		MultipartRequest mrequest=f.fileUpload();
		String url = mrequest.getParameter("url");
		String adname = mrequest.getOriginalFileName("adname");
		CDao dao = new CDao();
		dao.insertAd(adname,url);
		return "/Select.do";
	}

}
