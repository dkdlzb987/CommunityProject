package com.company;

import javax.servlet.http.HttpServletRequest;

public class LoginHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		return "/login.jsp";

	}

}
