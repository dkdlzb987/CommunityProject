package com.company;


import javax.servlet.http.HttpServletRequest;

public class InsertAdHandler implements CHandler {
	public String process(HttpServletRequest request){
		return "/adinsert.jsp";
	}
}
