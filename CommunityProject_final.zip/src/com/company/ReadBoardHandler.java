package com.company;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

public class ReadBoardHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		CDao dao = new CDao();
		int idx = Integer.parseInt(request.getParameter("idx"));
		request.setAttribute("data",dao.getReadContent(idx));
		

		Vector<CDto> c = dao.getComment(idx);
		request.setAttribute("commnetData", c);
		
		return "/readBoard.jsp";
	}

}
