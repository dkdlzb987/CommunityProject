package com.company;

import javax.servlet.http.HttpServletRequest;

public class GoodCntHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		CDao dao = new CDao();
		int idx = Integer.parseInt(request.getParameter("idx"));
		dao.goodCount(idx);
		
		// 좋아요수 업데이트
		// UPDATE cboard set goodCount=1 WHERE idx=16;
		return "/ReadBoard.do?idx="+idx;
	}

}
