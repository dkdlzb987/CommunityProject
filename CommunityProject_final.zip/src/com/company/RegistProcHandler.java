package com.company;

import javax.servlet.http.HttpServletRequest;

public class RegistProcHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		
		String name = request.getParameter("name");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String nickname = request.getParameter("nickname");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String addr = request.getParameter("addr");
		String answer = request.getParameter("answer");
		CDao dao = new CDao();
		dao.registMember(name,id,pw,nickname,email,phone,addr,answer);
		return "redirect:/Login.do";
	}

}
