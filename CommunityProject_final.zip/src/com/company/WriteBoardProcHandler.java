package com.company;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;

public class WriteBoardProcHandler implements CHandler {

	@Override
	public String process(HttpServletRequest request) {
		CFile f = new CFile(request);
		MultipartRequest mrequest=f.fileUpload();		
		
		String title = mrequest.getParameter("title");
		String content = mrequest.getParameter("content");
		String uploadFile = mrequest.getFilesystemName("uploadFile");
		String name = mrequest.getParameter("name");
		int boardNumber = Integer.parseInt(mrequest.getParameter("boardNumber"));
		CDao dao = new CDao();
		if(uploadFile==null){
			boardNumber = dao.writeBoard(title, content, name, boardNumber);
		}else{
			boardNumber = dao.writeBoard(title, content, name, uploadFile,boardNumber);
		}
		
		if( boardNumber==1){
			return "/HumorBoard.do";
		}else if( boardNumber==2){
			return "/PetBoard.do";
		}else {
			return "/GameBoard.do";
		}
		
	}

}
